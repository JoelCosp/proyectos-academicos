<?php
    // Creamos las constantes que usaremos a lo largo de nuestra aplicacion web
    
    // La url base  
    define("URL", "http://localhost/laMallorquina/");
    // La accion por defecto que realizara cada controlador al ser llamado y si no se le proporciona una accion determinada
    define("action_default", "index");
?>